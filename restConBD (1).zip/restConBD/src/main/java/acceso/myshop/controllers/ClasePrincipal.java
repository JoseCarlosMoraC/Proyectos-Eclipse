 package acceso.myshop.controllers;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClasePrincipal {

    public static void main(String[] args) {
        SpringApplication.run(ClasePrincipal.class, args);
    }
}
  