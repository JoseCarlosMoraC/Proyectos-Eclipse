package com.spring.springcoachx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcoachxApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcoachxApplication.class, args);
	}

}
