package Examen.Exception;

public class TorneoException extends Exception{
	  public TorneoException(String mensaje) {
	        super(mensaje);
	    }
}
