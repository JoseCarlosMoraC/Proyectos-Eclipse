package Examen.Models;

public enum Videojuego {
LOL, VALORANT, CSGO;


}
