package Simulacro.BancoDeAlimentos.Controllers;

import java.util.List;

import org.apache.logging.log4j.LogManager;

import Simulacro.BancoDeAlimentos.Models.CentroLogistico;
import Simulacro.BancoDeAlimentos.Models.Trabajador;
import Simulacro.BancoDeAlimentos.Utils.XMLDomBancoAlimentos;

public class GestionaBancoAlimentos {
	private static final org.apache.logging.log4j.Logger logger= LogManager.getLogger(GestionaBancoAlimentos.class);
	
	public static void main(String[] args) {

		XMLDomBancoAlimentos xmlbanco = new XMLDomBancoAlimentos();

		

		try {

			List<CentroLogistico> banco = xmlbanco.leerCentroLogisticoDesdeXML("bancoAlimentos.xml");
			List<Trabajador> trabajador = xmlbanco.leerTrabajadorDesdeXML("bancoAlimentos.xml");
			


			logger.info(banco);

		} catch (Exception e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

	}

}

