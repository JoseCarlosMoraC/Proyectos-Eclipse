package Simulacro.BancoDeAlimentos.Models;

public enum Tipo {
ASALARIADO, VOLUNTARIO
}
