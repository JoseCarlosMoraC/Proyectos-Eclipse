package Simulacro.BancoDeAlimentos.Exception;

public class BancoException extends Exception{
	  public BancoException(String mensaje) {
	        super(mensaje);
	    }
	}



