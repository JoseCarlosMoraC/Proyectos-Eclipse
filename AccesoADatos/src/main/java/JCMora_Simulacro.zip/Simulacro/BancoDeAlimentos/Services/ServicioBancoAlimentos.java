package Simulacro.BancoDeAlimentos.Services;

import org.apache.logging.log4j.LogManager;

import Simulacro.BancoDeAlimentos.Repositories.BancoAlimentos;

public class ServicioBancoAlimentos {
	private static final org.apache.logging.log4j.Logger logger = LogManager.getLogger(ServicioBancoAlimentos.class);
	BancoAlimentos repo;

}
