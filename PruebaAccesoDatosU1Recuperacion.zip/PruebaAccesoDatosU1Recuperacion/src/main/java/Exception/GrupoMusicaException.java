package Exception;

public class GrupoMusicaException extends Exception {
    public GrupoMusicaException(String mensaje) {
        super(mensaje);
    }
}