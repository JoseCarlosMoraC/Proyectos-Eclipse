package Models;

public enum Escenario {
PRINCIPAL, SECUNDARIO, ALTERNATIVO
}
