package acceso.veterinaria.models;

public enum TipoAnimal {
	PERRO, GATO, AVE, REPTIL, ROEDOR, OTRO;
}
