package Exceptions;

public class MiExcepcion extends Exception {

    public MiExcepcion(String mensaje) {
        super(mensaje);
    }
}
